
import User from '@/api/User'
import { reject } from 'lodash'
export default {
    namespaced:true,
    state:{
        carry:[],
        orders:[],
        
    },
    mutations:{
        SET_CARRY(state,payload){
            state.carry.push(payload)
        },
        DELETE_BY_ID(state,id){
            state.carry.splice(id,1)
        },
        UPDATE_CARRY(state,payload){
            var busqueda = _.find(state.carry, ['id',payload.id])
            //si está
            if(typeof busqueda == 'object'){
              //si está en el carrito dame el indice en la posición del array
                var index = _.indexOf(state.carry, busqueda)
                state.carry[index].Quantity++
            }
        },
        UPDATE_CARRY_DEC(state,payload){
            var busqueda = _.find(state.carry, ['id',payload.id])
            //si está
            if(typeof busqueda == 'object'){
              //si está en el carrito dame el indice en la posición del array
                var index = _.indexOf(state.carry, busqueda)
                if(state.carry[index].Quantity==1){
                    state.carry.splice(index, 1);
                } else {
                    state.carry[index].Quantity--
                }
           }
        },
        GET_ORDERS(state,id){
           
            
                
        },
        
        
    },
    actions:{
        ADD_CARRY({commit},payload){
            commit("SET_CARRY",payload)
        },
        DELETE_CARRY_BY_ID({commit},id){
            commit('DELETE_BY_ID',id)
        },
        UPDATE_CARRY_QTY({commit},payload){
            commit('UPDATE_CARRY',payload)
        },
        UPDATE_CARRY_DEC({commit},payload){
            commit('UPDATE_CARRY_DEC',payload)
        },
        GET_ORDERS({commit},id){
            commit('GET_ORDERS',id)
        },
       
        UPDATE_ORDER({state,commit},id,form){
            User.get_orders_by_id(id)
            .then(response =>
                state.orders = response.data.orders)
            .catch(error=> console.error(error))
        },
        
        

        
    }
}