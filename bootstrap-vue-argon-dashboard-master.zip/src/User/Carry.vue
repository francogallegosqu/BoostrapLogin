<template>
  <div>
    <base-header class="pb-6 pb-8 pt-5 pt-md-8 bg-gradient-success">
      <!-- Card stats -->
      <b-row> </b-row>
    </base-header>
    <h2 class="text-center m-3">CARRY</h2>
    <!-- <div>
      <b-table striped hover :items="carry" :fields="fields">
        <template #cell(actions)="data">
          <b-button>{{ `comprar S/. ${data.item.Price}` }}</b-button>
        </template>
      </b-table>
    </div> -->
    <ul>
      <li v-for="item in arre" :key="item.id">{{item}}</li>
    </ul>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { mapActions } from "vuex";
import User from '@/api/User'
export default {
  name: "carry",
  data() {
    return {
      pendientes:{},
      arre:[],
      fields: [
        "Tittle",
        { key: "Price", label: "precio" },
        "Description",
        "Quantity",
        "actions"
      ]
    };
  },
  created(){
    this.SET_USER()
    this.GET_ORDERS(this.user.id)
    console.log(this.user.id)
    console.log(this.orders)
    // console.log(this.orders.data.orders)
    // User.get_orders_by_id(this.user.id)
    //         .then(response =>{
    //           console.log(response.data.orders)
    //         }
    //         )
    //         .catch(error=> console.error(error))
    
  },
  mounted(){
    
    // let pend=this.orders.filter(obj=>obj.TotalAmount==0)
    // console.log(pend)
    // this.pendientes=pend[0]
    // this.arre=this.pendientes.detalle_ordens
    // console.log(this.arre)
  },
  computed: {
    ...mapState("MUser", ["user"]),
    ...mapState("Mcarry", ["carry","orders"]),
  },
  methods:{
    ...mapActions("Mcarry",["GET_ORDERS","ADD_WAITING"]),
    ...mapActions('MUser',['SET_USER']),
  }
};
</script>
